// #ifndef __DATALOADER_H__
// #define __DATALOADER_H__


// #include<istream>
// #include<vector>
// #include<sstream>
// #include<fstream>
// using namespace std;


// typedef struct { //边缘节点
//     int id;
//     string site_name;
//     int bandwidth;
// }site;

// typedef struct  //分配信息
// {
//     string site_name_from;
//     int bandwidth;
// }info;

// class customer{ //客户
//     public:
//         customer(int id, string customer_name):id(id), customer_name(customer_name){}
//         int id;
//         string customer_name;
//         vector<int> bandwidth_need; //需求带宽
//         vector<int> qos; //需求qos
//         vector<vector<info>> infos; //分配的结果
// };

// extern int site_num; //number of sites
// extern int customer_num; // number of customers
// extern int T; //number of time
// extern vector<site> sites; //边缘节点的集合
// extern vector<customer> customers; //客户的集合
// extern int Qos;    // Qos


// void initializeData();

// #endif